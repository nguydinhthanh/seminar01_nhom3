# Copyright (c) Recommenders contributors.
# Licensed under the MIT License.

import os
import pandas as pd
from typing import Dict, List

# Modified function to load local datasets instead of downloading from the internet
def load_item_df(size="100k", local_path=None, movie_col="itemID", title_col="movie_title", genres_col="genres") -> pd.DataFrame:
    """
    Load the item dataframe from a local path for MovieLens dataset (u.item for 100k or movies.dat for 1m).

    Args:
        size (str): The size of the dataset, e.g., "100k", "1m".
        local_path (str): Local path to the MovieLens dataset file.
        movie_col (str): Column name to use for the movie IDs.
        title_col (str): Column name to use for the movie titles.
        genres_col (str): Column name to use for genres.

    Returns:
        pd.DataFrame: A DataFrame containing movie information.
    """
    if local_path is None or not os.path.exists(local_path):
        raise ValueError(f"The specified local_path '{local_path}' does not exist. Please provide a valid path.")

    if size == "100k":
        # Define column names for u.item format
        column_names = [
            "itemID", "movie_title", "release_date", "video_release_date", "IMDb_URL",
            "unknown", "Action", "Adventure", "Animation", "Children's", "Comedy", "Crime",
            "Documentary", "Drama", "Fantasy", "Film-Noir", "Horror", "Musical", "Mystery",
            "Romance", "Sci-Fi", "Thriller", "War", "Western"
        ]

        # Read the dataset
        df = pd.read_csv(local_path, sep="|", header=None, names=column_names, encoding="ISO-8859-1")

        # Ensure essential columns are not missing
        df = df.dropna(subset=["itemID", "movie_title"])

        # Select and rename relevant columns
        df = df[["itemID", "movie_title"]]
        df.rename(columns={"itemID": movie_col, "movie_title": title_col}, inplace=True)

    elif size == "1m":
        # Define column names for movies.dat format
        column_names = ["itemID", "movie_title", "genres"]

        # Read the dataset
        df = pd.read_csv(local_path, sep="::", engine="python", header=None, names=column_names, encoding="ISO-8859-1")

        # Ensure essential columns are not missing
        df = df.dropna(subset=["itemID", "movie_title"])

        # Rename columns to user-defined names
        df.rename(columns={"itemID": movie_col, "movie_title": title_col, "genres": genres_col}, inplace=True)

    else:
        raise ValueError(f"Unsupported size '{size}'. Supported sizes are '100k' and '1m'.")

    return df


def load_pandas_df(local_path=None, sep="::", header=None, column_names=None) -> pd.DataFrame:
    """
    Load a pandas DataFrame from a local file (e.g., ratings.dat from MovieLens).

    Args:
        local_path (str): Local path to the dataset file (ratings.dat).
        sep (str): Delimiter to use for separating values in the file (default is '::' for ratings.dat).
        header (int or None): Row number to use as the column names. None if no header exists.
        column_names (List[str]): List of column names to assign to the DataFrame.

    Returns:
        pd.DataFrame: A DataFrame containing the dataset.
    """
    if local_path is None or not os.path.exists(local_path):
        raise ValueError(f"The specified local_path '{local_path}' does not exist. Please provide a valid path.")

    # Load the dataset
    df = pd.read_csv(local_path, sep=sep, engine="python", header=header, names=column_names, encoding="ISO-8859-1")

    return df
