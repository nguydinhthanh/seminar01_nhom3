# Copyright (c) Recommenders contributors.
# Licensed under the MIT License.

from .sar_singlenode import SARSingleNode as SAR  # noqa: F401
